package com.leyou.item.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.leyou.common.dto.CartDTO;
import com.leyou.common.enums.ExceptionEnum;
import com.leyou.common.exception.LyException;
import com.leyou.common.vo.PageResult;
import com.leyou.item.pojo.*;
import org.apache.commons.lang.StringUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import tk.mybatis.mapper.entity.Example;

import java.util.*;
import java.util.stream.Collectors;

public interface GoodsService {
    public PageResult<Spu> querySpuByPage(Integer page, Integer rows, Boolean saleable, String key);

    public void loadCaegroaryAndBrandName(List<Spu> spus);

    /**
     * 新增商品
     * @param spu
     */
    @Transactional
    public void saveGoods(Spu spu);

    /**
     * 新增sku和库存
     * @param spu
     */
   public void saveSkuAndStock(Spu spu);

    public List<Sku> querySkuBySpuId(Long spuId);

    /**
     * 修改商品信息
     * @param spu
     */
    @Transactional
    public void updateGoods(Spu spu);


    public Spu querySpuById(Long id);

    /**
     * 商品删除二合一（多个单个）
     * @param id
     */
    @Transactional(rollbackFor = Exception.class)
    public void deleteGoods(long id);



    /**
     * 根据skuId查询sku
     * @param id
     * @return
     */
    public Sku querySkuById(Long id);


    /**
     * 根据sku的集合查询所有sku
     * @param ids
     * @return
     */
    public List<Sku> querySkuByIds(List<Long> ids) ;

    public void fillStock(List<Long> ids, List<Sku> skus);

    @Transactional
    public void decreaseStock(List<CartDTO> carts);
        /*
         * 这里不建议用锁，这样就把减库存当做单线程操作了，同一时刻只能一个人操作
         * 性能很差，高并发时不能满足要求
         * 是悲观锁
         * 有线程安全问题
         * */
        /*
         * 因此我们使用乐观锁，不做查询，不作判断，直接就减库存
         * 在SQL语句中加入判断 where sku_id = #{skuId} and stock >= #{num}，
         * 这样有一百个人抢，执行成功的条件就是stock满足条件
         * */

        /**
         * 商品下架
         * @param id
         */
        @Transactional(rollbackFor = Exception.class)
        public void goodsSoldOut (Long id);
    public SpuDetail queryDetailById(Long spuId);
}