package com.leyou.item.mapper;

import com.leyou.item.pojo.Specification;
import tk.mybatis.mapper.common.Mapper;

@org.apache.ibatis.annotations.Mapper
public interface SpecificationMapper extends Mapper<Specification> {
}