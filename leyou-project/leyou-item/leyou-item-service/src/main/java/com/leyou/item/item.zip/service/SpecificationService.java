package com.leyou.item.service;

import com.leyou.common.enums.ExceptionEnum;
import com.leyou.common.exception.LyException;
import com.leyou.item.pojo.SpecGroup;
import com.leyou.item.pojo.SpecParam;
import com.leyou.item.pojo.Specification;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author guo
 */
public interface SpecificationService {
    public List<SpecGroup> querySpecGroupByCid(Long cid);

    public List<SpecParam> querySpecParamList(Long gid, Long cid, Boolean searching);

    public List<SpecGroup> queryListByCid(Long cid);
    /**
     * 根据id查询规格参数模板
     * @param id
     * @return
     */
//    public Specification queryById(Long id) {
//        return this.specificationMapper.selectByPrimaryKey(id);
//    }

    /**
     * 保存规格参数模板
     * @param specification
     */
    public void saveSpecification(Specification specification);

    /**
     * 修改规格参数模板
     * @param specification
     */
    public void updateSpecification(Specification specification);

    /**
     * 删除规格参数模板
     * @param specification
     */
    public void deleteSpecification(Specification specification);
}
