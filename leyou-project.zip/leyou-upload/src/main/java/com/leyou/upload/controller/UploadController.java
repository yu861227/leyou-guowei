package com.leyou.upload.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author guo
 */
@Controller
@RequestMapping("upload")
public class UploadController {

    @PostMapping("image")
    public ResponseEntity<String> uploadImage(){
          return null;
    }






}
