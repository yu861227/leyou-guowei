package com.leyou.item.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.leyou.common.enums.ExceptionEnum;
import com.leyou.common.exception.LyException;
import com.leyou.common.vo.PageResult;
import com.leyou.item.mapper.BrandMapper;
import com.leyou.item.pojo.Brand;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import tk.mybatis.mapper.entity.Example;

import java.util.List;

/**
 * @author guo
 */
public interface BrandService {

    public PageResult<Brand> queryBrandByPage(
            Integer page, Integer rows, String sortBy, Boolean desc, String search);



   /**
     * 品牌更新
     * @param brand
     * @param categories
     */
    @Transactional(rollbackFor = Exception.class)
    public void updateBrand(Brand brand,List<Long> categories);


    public Brand queryById(Long id);

    public List<Brand> queryBrandByCid(Long cid);


    public List<Brand> queryByIds(List<Long> ids);


     /**品牌删除
     @param id
     **/
    @Transactional(rollbackFor = Exception.class)
    public void deleteBrand(Long id);


     /** 删除中间表中的数据
     * @param bid
     */
    public void deleteByBrandIdInCategoryBrand(Long bid);





   void saveBrand(Brand brand, List<Long> cids);
}
