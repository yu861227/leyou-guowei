package com.leyou.item.service;

import com.leyou.item.pojo.Category;

import java.util.List;

/**
 * @author guo
 */
public interface CategoryService {
    List<Category> querCategoriesByPid(Long pid);
}
